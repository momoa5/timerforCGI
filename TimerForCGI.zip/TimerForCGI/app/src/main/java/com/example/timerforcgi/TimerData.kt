package com.example.timerforcgi

class TimerData (
    val time:String
  )